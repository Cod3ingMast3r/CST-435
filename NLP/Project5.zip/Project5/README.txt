Parker, Alex, Matthew
10/15/2023
Project 5
This project asked students to create and "draw" their scenes from project 3,4 utilizing OpenGL. 
This was to be more realistic than the last.

In order to run this code on your machine

1) Download Project5 folder  entering cd <directory where Project5 (should be Downloads)>. Then cd into Project5 (to be in environment to run).

2) With the above downloads Linux MUST HAVE GLUT, GLU, SOIL and OpenGL
   2.5) command to download soil:  sudo apt-get install libsoil-dev  

3) Input:   make       this runs off of a make file

4) With the window open click on the window and use arrow keys to move around scene

5) Click x on the top of the window to close the scene

6) To get rid of scene file that is created input:  make clean

7) WITH ISSUES LET PARKER KNOW