// Parker, Alex, Matthew
// 10/04/23
// Below is the code for Project 4. This code utilizes basic openGL commands to make a 2D portrait of the picture that was chosen from Project 3. This utilized
// polygons, lines, and colors from the picture to render with our graphics. This will potentially be expanded to 3D in the future.
// In addition this is the first time that a camera is utilized for the scene being able to "look" around the scene. Although the scene is 2D this was something good to attempt
#include <iostream>
#include <GL/glut.h>
#include <GL/gl.h>
#include <stdlib.h>
#include <SOIL/SOIL.h>
#include <filesystem>
#include <limits.h>
#include <unistd.h>

#include "textures.cpp"

GLfloat cameraPosX = 1.0f; //setting up the x position of the camera
GLfloat cameraPosY = 1.0f; //setting up the y position of the camera
GLfloat cameraPosZ = 1.0f; //setting up the z position of the camera
covers cover;              //initializing the class being call


void start() { // where the rendering begins
    
    glClear(GL_COLOR_BUFFER_BIT);
    
    glClearColor(1.0f, 1.0f, 1.0f, 0.0); // setting the background color
    glMatrixMode(GL_PROJECTION);      // sets the perspective that will be seen
    gluOrtho2D(0.0, 710, 0.0, 590);   // setting the size that will be utilized when drawing

    
}



void dryer() {
    // This line calls our class to initialize our textures
    
    //INPUT YOUR SPECIFIC FILE PATH HERE
    //Path_max Maximum number of bytes in a pathname, including the terminating null character.
    char buffer[PATH_MAX]; //creating a character array called buffer
    ssize_t len = readlink("/proc/self/exe", buffer, sizeof(buffer) - 1); // this is getting the current code that is running. Creating a buffer
    if (len != -1) { // if there is a value that comes into the nuffer(path) then we will ahve a path.
        buffer[len-6] = '\0'; // cutting the end of the array to get the value desired for grapping photos
    } 
    else {
        std::cerr << "Error: Unable to retrieve executable path." << std::endl; // this means bd things :(
    }

    std:: string filepath(buffer);

    GLuint upperLeftControl, instruction, leftHandle, leftControl, background, rightHandle, rightNumber, leftNumber, rightControl, recycleBag; //initializing the names for textures
    upperLeftControl = cover.init(filepath + "/pics/cardreader.png"); // sending the found file name with the correct file to have the texture made
    instruction = cover.init(filepath +  "/pics/nInstruction.png");
    leftHandle = cover.init(filepath + "/pics/leftHandle.png");
    leftControl = cover.init(filepath + "/pics/leftControl.png");
    background = cover.init(filepath + "/pics/background.png");
    rightHandle = cover.init(filepath + "/pics/rightHandle.png");
    rightNumber = cover.init(filepath + "/pics/rightNumber.png");
    leftNumber = cover.init(filepath + "/pics/leftNumber.png");
    rightControl = cover.init(filepath + "/pics/rightControl.png");
    recycleBag = cover.init(filepath + "/pics/topCan.png");

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(cameraPosX, cameraPosY, cameraPosZ,   // Camera position
              cameraPosX, cameraPosY, 0.0f,         // Look-at point
              0.0f, 1.0f, 0.0f);                    // Up vector
    
    glClear(GL_COLOR_BUFFER_BIT);

    
    //BackGround
    glEnable(GL_TEXTURE_2D); //enaling our 2D design
    glBindTexture(GL_TEXTURE_2D, background); // starting to wrap our object with the texture that is created
    glDisable(GL_LIGHTING);  // getting rid of the lighting
    glBegin(GL_POLYGON);   // start making our shape
    glColor3f(1.0f, 1.0f, 1.0f);   // making the texture "bright" in order for it to be seen
    glTexCoord2f(0.0, 0.0); glVertex2i(0,0);  // this is where we do the wrap and create the object
    glTexCoord2f(0.0, 1.0); glVertex2i(0,590);
    glTexCoord2f(1.0, 1.0); glVertex2i(710, 590);
    glTexCoord2f(1.0, 0.0); glVertex2i(710, 0);
    glEnd();
    glDisable(GL_TEXTURE_2D); //stopping the work for this 2D object


    glBegin(GL_POLYGON); // recycle bin 
    glColor3f(0.15f, 0.15f, 0.45f);
    glVertex2i(6,590 - 401);
    glVertex2i(35,85);
    glVertex2i(80, 80);
    glVertex2i(70, 590-402);
    glEnd();

    // top of recycle bin    MAY COME BACK TO TO CLEAN UP. NEED FILE PATH TO WORK FIRST
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, recycleBag);
    glDisable(GL_LIGHTING);
    glBegin(GL_POLYGON); 
    glColor3f(1.0f, 1.0f, 1.0f);
    glTexCoord2f(0.0, 0.0); glVertex2i(6, 590-405);
    glTexCoord2f(0.0, 1.0); glVertex2i(0,590-374);
    glTexCoord2f(1.0, 1.0); glVertex2i(65, 590-335);
    glTexCoord2f(1.0, 0.0); glVertex2i(70, 590 - 415);
    glEnd();
    glDisable(GL_TEXTURE_2D);


                          
    glBegin(GL_POLYGON);  //Left Dryer
    glColor3f(0.52f , 0.5f, 0.45f);
    glVertex2i(42, 420);
    glVertex2i(85,53);
    glVertex2i(373,51);
    glVertex2i(367,423);
    glEnd();
                         

    glBegin(GL_POLYGON);  //Left Dryer Upper (had to make this as the top slopes back to the right again)
    glColor3f(0.52f , 0.5f, 0.45f);
    glVertex2i(35, 545);
    glVertex2i(41,420);
    glVertex2i(367,423);
    glVertex2i(367,546);
    glEnd();
    
    glBegin(GL_POLYGON); //Right Dryer
    glColor3f(0.52f , 0.5f, 0.45f);
    glVertex2i(367, 444);
    glVertex2i(374,51);
    glVertex2i(675,55);
    glVertex2i(710,444);
    
    glEnd();

    glBegin(GL_POLYGON); //Right Dryer upper
    glColor3f(0.52f , 0.5f, 0.45f);
    glVertex2i(368,510);
    glVertex2i(368,443);
    glVertex2i(628,443);
    glVertex2i(621, 510);
    glEnd();

    glBegin(GL_LINES); // left door on dryer
    glColor3f(0.0f, 0.0f, 0.0f);
    
    glVertex2f(70,403);
    glVertex2f(89,193);

    glVertex2f(70,403);
    glVertex2f(347,406);

    glVertex2f(352,196);
    glVertex2f(347,406);

    glVertex2f(89,193);
    glVertex2f(352,196);
    glEnd();

    glBegin(GL_LINES); //right door on dryer
    glColor3f(0.0f, 0.0f, 0.0f);
    
    glVertex2f(392,406);
    glVertex2f(395,193);

    glVertex2f(395,193);
    glVertex2f(670,193);

    glVertex2f(670,193);
    glVertex2f(687,406);

    glVertex2f(687,406);
    glVertex2f(392,406);
    glEnd();

    glBegin(GL_LINES); // This will be the lines around the doors that split up the pannelling
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(70,163); // lower panel left
    glVertex2f(370,165);

    glVertex2f(375,163); // lower panel right
    glVertex2f(684,165);

    glVertex2f(47,420); // upper panel left
    glVertex2f(367,420);

    glVertex2f(371,420); // upper panel right
    glVertex2f(708,421);
    
    glVertex2f(38,531); // above left card / control panel
    glVertex2f(364,533);
    glEnd();


    // left control panel
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, leftControl);
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);
    glTexCoord2f(0.0, 1.0); glVertex2i(117,512);
    glTexCoord2f(0.0, 0.0); glVertex2i(119,440);
    glTexCoord2f(1.0, 0.0); glVertex2i(283,440);
    glTexCoord2f(1.0, 1.0); glVertex2i(280, 512);
    glEnd();
    glDisable(GL_TEXTURE_2D);


    // left card reader panel
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D,upperLeftControl );
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);
    glTexCoord2f(0.0, 1.0);glVertex2i(48,528);
    glTexCoord2f(0.0, 0.0);glVertex2i(52,435);
    glTexCoord2f(1.0, 0.0);glVertex2i(104,435);
    glTexCoord2f(1.0, 1.0);glVertex2i(100, 528);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    

    // left instruction panel
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, instruction);
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);
    glTexCoord2f(0.0, 1.0); glVertex2i(299,528);
    glTexCoord2f(0.0, 0.0); glVertex2i(302,435);
    glTexCoord2f(1.0, 0.0); glVertex2i(354,435);
    glTexCoord2f(1.0, 1.0); glVertex2i(352, 528);
    glEnd();
    glDisable(GL_TEXTURE_2D);

    
    // right dryer panel
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, rightControl);
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);
    glTexCoord2f(0.0, 1.0); glVertex2i(380,500);
    glTexCoord2f(0.0, 0.0); glVertex2i(381,457);
    glTexCoord2f(1.0, 0.0); glVertex2i(617,457);
    glTexCoord2f(1.0, 1.0); glVertex2i(614, 500);
    glEnd();
    glDisable(GL_TEXTURE_2D);


    // left dryer door Number Pad
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, leftNumber);
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON); 
    glTexCoord2f(0.0, 1.0); glVertex2i(80,590 - 190);
    glTexCoord2f(0.0, 0.0); glVertex2i(81,590 - 233);
    glTexCoord2f(1.0, 0.0); glVertex2i(112,590 - 233);
    glTexCoord2f(1.0, 1.0); glVertex2i(111, 590 - 190);
    glEnd();
    glDisable(GL_TEXTURE_2D);


    // right dryer door Number Pad
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, rightNumber);
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON); 
    glTexCoord2f(0.0, 1.0); glVertex2i(642,590 - 190);
    glTexCoord2f(0.0, 0.0); glVertex2i(638,590 - 235);
    glTexCoord2f(1.0, 0.0); glVertex2i(669,590 - 235);
    glTexCoord2f(1.0, 1.0); glVertex2i(674, 590 - 190);
    glEnd();
    glDisable(GL_TEXTURE_2D);


    // left drier door handle
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, leftHandle);
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);
    glTexCoord2f(0.0, 1.0); glVertex2i(92, 590 - 263);
    glTexCoord2f(0.0, 0.0); glVertex2i(92, 590 - 324);
    glTexCoord2f(1.0, 0.0); glVertex2i(128, 590 - 324);
    glTexCoord2f(1.0, 1.0); glVertex2i(128, 590 - 263);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    

    // right drier door handle
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, rightHandle);
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);  
    glTexCoord2f(0.0, 1.0); glVertex2i(418, 590 - 262);
    glTexCoord2f(0.0, 0.0); glVertex2i(418, 590 - 315);
    glTexCoord2f(1.0, 0.0); glVertex2i(440, 590 - 315);
    glTexCoord2f(1.0, 1.0); glVertex2i(440, 590 - 261);
    glEnd();
    glDisable(GL_TEXTURE_2D);


    glFlush();
}
void specialKeys(int key, int x, int y) { // this special key  is mainly for cameras as of now (up, down, left, right) but may be built out later on

    
    switch (key) {
        case GLUT_KEY_UP:  // if the key is up move up 5 pixels
            cameraPosY += 5;
            break;
        case GLUT_KEY_DOWN:
            cameraPosY -= 5;
            break;
        case GLUT_KEY_LEFT:
            cameraPosX -= 5;
            break;
        case GLUT_KEY_RIGHT:
            cameraPosX += 5;
            break;
    }

    std::cout << "cameraPosX: " << cameraPosX << ", cameraPosY: " << cameraPosY << std::endl; //this was for debugging. the console will print out the coordinates of the                                                                                             // camera as it is moved.
    glutPostRedisplay();   //this simply updates what is seen on screen
    
}

namespace fs = std::filesystem;

int main(int argc, char **argv) {

    

   
    // Initialize GLUT
    glutInit(&argc, argv);
    // Set display mode
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    // Set top-left display window position.
    glutInitWindowPosition(100, 100);
    // Set display window width and height
    glutInitWindowSize(710, 590);

    // Create display window with the given title
    glutCreateWindow("Scene1");
    // Execute initialization procedure
    start();
    // Send graphics to display window
    glutDisplayFunc(dryer);
    glutSpecialFunc(specialKeys);
    // Display everything and wait.
    glutMainLoop();

    return 0;
}